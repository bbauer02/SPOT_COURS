# Dockerfile pour apache avec php-fpm

L'image `php-fpm` est une image spéciale permettant la reception et l'émission de requête `fcgi`.


```
FROM httpd:2.4

# Activation des modules nécessaires
RUN sed -i '/LoadModule proxy_module/s/^#//g' /usr/local/apache2/conf/httpd.conf && \
    sed -i '/LoadModule proxy_fcgi_module/s/^#//g' /usr/local/apache2/conf/httpd.conf

# Configuration simple et directe pour PHP-FPM
COPY <<EOF /usr/local/apache2/conf/extra/php-fpm.conf
# Configuration du proxy vers PHP-FPM
ProxyPassMatch "^/(.*\\.php(/.*)?)\$" fcgi://php:9000/var/www/html/\$1

# Configuration du répertoire
<Directory /var/www/html>
    DirectoryIndex index.php index.html
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
EOF

# Inclusion de la configuration PHP et changement du DocumentRoot
RUN echo "Include conf/extra/php-fpm.conf" >> /usr/local/apache2/conf/httpd.conf && \
    sed -i 's|/usr/local/apache2/htdocs|/var/www/html|' /usr/local/apache2/conf/httpd.conf

EXPOSE 80
```


La commande ``sed -i '/LoadModule proxy_module/s/^#//g' /usr/local/apache2/conf/httpd.conf`` 

sed est un éditeur de texte en ligne de commande. 

L'option -i permet de modifier un fichier directement sur place. 

On cherche ici à retirer le # de la ligne "proxy_module" du fichier httpd.conf



## Utilisation : 

* docker network create web-network
* docker run -d --name php --network web-network -v $PWD:/var/www/html php:fpm
* docker build -t my-apache .
*  docker run -d --name apache -p 80:80 --network web-network  -v $PWD/:/var/www/html my-apache


